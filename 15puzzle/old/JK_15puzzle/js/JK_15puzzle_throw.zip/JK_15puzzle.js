const boxContainer = document.getElementById('boxContainer');
const boxItems = document.querySelectorAll('boxItem');
const activeBox = document.getElementsByClassName('.activeBox')[0];
const randomBtn = document.querySelector('#randomBtn');

// 그래픽 처리
const HORIZONMOVEPX = 100;
const VERTICALMOVEPX = 100;

// 배열 처리
let currentPosiIndex;
let tempNewPosiVal;
const currentPuzzleArr = [];
const answerPuzzleArr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0];

document.addEventListener('keydown', goDirection);
randomBtn.addEventListener('click', makeRandom);

setNewGame();

function setNewGame() {
  makeRandom();

  // 16조각 position 지정
  for (let boxItem of boxItems) {
    let x = Math.floor(i % 4);
    let y = Math.floor(i / 4);
    boxItem.style.left = `${HORIZONMOVEPX * x}px`;
    boxItem.style.top = `${VERTICALMOVEPX * y}px`;
  }

}

function makeRandom() {

  // 0값 가진 태그 activeBox 클래스 제거
  // + transition 0 설정
  for (let boxItem of boxItems) {
    if (boxItem.classList.contains('activeBox')) {
      boxItem.classList.remove('activeBox');
    }
    boxItem.classList.add('boxItemTransitionNone');
  }

  currentPuzzleArr.length = 0;  // 배열 초기화

  while (true) {
    // 중복 없이 랜덤으로 0~15 숫자 뽑아 배열에 넣는다.
    let randomNum = Math.floor(Math.random() * 16);

    // 배열에 넣기전에 중복인지 검사 후 넣기
    if (!currentPuzzleArr.includes(randomNum)) {
      currentPuzzleArr.push(randomNum);

      // 길이 16이면 종료
      if (currentPuzzleArr.length === 16) {
        break;
      }
    }
  }
  // console.log(`${currentPuzzleArr}`);

  // 배열 data-index 순서대로 숫자를 div에 넣는다.
  let idx = 0;
  for (let boxItem of boxItems) {
    boxItem.innerText = currentPuzzleArr[idx++];
    console.log(boxItem)
  }
  console.log(currentPuzzleArr);

  currentPosiIndex = currentPuzzleArr.indexOf(0);

  // innerText가 0인 tag에 activeBox 클래스 주기
  for (let boxItem of boxItems) {
    if (+boxItem.innerText == 0) {
      boxItem.classList.add('activeBox');
    }
  }

  // transition 복구
  for (let boxItem of boxItems) {
    boxItem.classList.remove('boxItemTransitionNone');
  }
}

function goDirection(e) {
  switch (e.key) {
    case 'ArrowUp':
      if (Math.floor(currentPosiIndex / 4) != 3) {  // 0 Arr의 index가 12~15 아닐때
        goUp();
      }
      break;
    case 'ArrowDown':
      if (Math.floor(currentPosiIndex / 4) != 0) {  // 0 Arr의 index가 0~3 아닐때
        goDown();
      }
      break;
    case 'ArrowLeft':
      if (currentPosiIndex % 4 != 3) {  // 0 Arr의 index가 3~~15 아닐때
        goLeft();
      }
      break;
    case 'ArrowRight':
      if (currentPosiIndex % 4 != 0) {  // 0 Arr의 index가 0~12 아닐때
        goRight();
      }
      break;
  }
}

function goUp() {
  let otherPosiIndex = currentPosiIndex + 4;  // 11 = 15 - 4
  // let currentBoxX = currentPosiIndex % 4;
  let currentBoxY = Math.floor((currentPosiIndex) / 4);

  //// 픽셀 바꾸기
  // 아래쪽 박스 위쪽으로
  let moveToOtherPx = currentBoxY * HORIZONMOVEPX;
  // arr 아래 박스 숫자로 boxItems 중 innerText의 동일한 숫자 찾아서 px 변경
  for (let boxItem of boxItems) {
    if (+boxItem.innerText == currentPuzzleArr[otherPosiIndex]) {
      boxItems.style.top = `${moveToOtherPx}px`;
    }
    // for (let i = 0; i < boxItems.length; i++) {
    //   if (+boxItems[i].innerText == currentPuzzleArr[otherPosiIndex]) {
    //     boxItems[i].style.top = `${moveToOtherPx}px`;
    //   }
  }

  // 0 박스 아래쪽으로
  let moveToActivePx = (currentBoxY + 1) * HORIZONMOVEPX;
  // boxItems 중 innerText가 0인 객체 찾아서 px 변경
  for (let boxItem of boxItems) {
    if (+boxItem.innerText == 0) {
      boxItem.style.top = `${moveToActivePx}px`;
    }
    // for (let i = 0; i < boxItems.length; i++) {
    //   if (+boxItems[i].innerText == 0) {
    //     boxItems[i].style.top = `${moveToActivePx}px`;
    //   }
  }

  //// 배열 바꾸기
  let otherValue = currentPuzzleArr[otherPosiIndex];    // other의 배열 값 가져오기
  tempNewPosiVal = otherValue;
  currentPuzzleArr[otherPosiIndex] = 0;  // other에 0 값 넣기
  currentPuzzleArr[currentPosiIndex] = tempNewPosiVal;

  currentPosiIndex = otherPosiIndex;
}

function goDown() {
  let otherPosiIndex = currentPosiIndex - 4;  // 11 = 15 - 4
  // let currentBoxX = currentPosiIndex % 4;
  let currentBoxY = Math.floor((currentPosiIndex) / 4);

  //// 픽셀 바꾸기
  // 위쪽 박스 아래쪽으로
  let moveToOtherPx = currentBoxY * HORIZONMOVEPX;
  for (let i = 0; i < boxItems.length; i++) {
    if (+boxItems[i].innerText == currentPuzzleArr[otherPosiIndex]) {
      boxItems[i].style.top = `${moveToOtherPx}px`;
    }
  }

  // 0 박스 위쪽으로
  let moveToActivePx = (currentBoxY - 1) * HORIZONMOVEPX;
  for (let i = 0; i < boxItems.length; i++) {
    if (+boxItems[i].innerText == 0) {
      boxItems[i].style.top = `${moveToActivePx}px`;
    }
  }

  //// 배열 바꾸기
  let otherValue = currentPuzzleArr[otherPosiIndex];    // other의 배열 값 가져오기
  tempNewPosiVal = otherValue;
  currentPuzzleArr[otherPosiIndex] = 0;  // other 값에 0 값 넣기
  currentPuzzleArr[currentPosiIndex] = tempNewPosiVal;
  currentPosiIndex = otherPosiIndex;

}

function goLeft() {
  let otherPosiIndex = currentPosiIndex + 1;  // 15 = 14 + 1
  let currentBoxX = currentPosiIndex % 4;
  // let currentBoxY = Math.floor((currentPosiIndex) / 4);

  //// 픽셀 바꾸기
  // 오른쪽 박스 왼쪽으로
  let moveToOtherPx = currentBoxX * HORIZONMOVEPX;
  for (let i = 0; i < boxItems.length; i++) {
    if (+boxItems[i].innerText == currentPuzzleArr[otherPosiIndex]) {
      boxItems[i].style.left = `${moveToOtherPx}px`;
    }
  }

  // 0 박스 오른쪽으로
  let moveToActivePx = (currentBoxX + 1) * HORIZONMOVEPX;
  // boxItems[currentPosiIndex].style.left = `${moveToActivePx}px`;
  for (let i = 0; i < boxItems.length; i++) {
    if (+boxItems[i].innerText == 0) {
      boxItems[i].style.left = `${moveToActivePx}px`;
    }
  }

  //// 배열 바꾸기
  let otherValue = currentPuzzleArr[otherPosiIndex];    // other의 배열 값 가져오기
  tempNewPosiVal = otherValue;
  currentPuzzleArr[otherPosiIndex] = 0;  // other 값에 0 값 넣기
  currentPuzzleArr[currentPosiIndex] = tempNewPosiVal;
  currentPosiIndex = otherPosiIndex;
}

function goRight() {
  let otherPosiIndex = currentPosiIndex - 1;  // 14 = 15 - 1
  let currentBoxX = currentPosiIndex % 4;
  // let currentBoxY = Math.floor((currentPosiIndex) / 4);

  //// 픽셀 바꾸기
  // 왼쪽 박스 오른쪽으로
  let moveToOtherPx = currentBoxX * HORIZONMOVEPX;
  for (let i = 0; i < boxItems.length; i++) {
    if (+boxItems[i].innerText == currentPuzzleArr[otherPosiIndex]) {
      boxItems[i].style.left = `${moveToOtherPx}px`;
    }
  }

  // 0 박스 왼쪽으로
  let moveToActivePx = (currentBoxX - 1) * HORIZONMOVEPX;
  for (let i = 0; i < boxItems.length; i++) {
    if (+boxItems[i].innerText == 0) {
      boxItems[i].style.left = `${moveToActivePx}px`;
    }
  }

  //// 배열 바꾸기
  let otherValue = currentPuzzleArr[otherPosiIndex];    // other의 배열 값 가져오기
  tempNewPosiVal = otherValue;
  currentPuzzleArr[otherPosiIndex] = 0;  // other 값에 0 값 넣기
  currentPuzzleArr[currentPosiIndex] = tempNewPosiVal;
  currentPosiIndex = otherPosiIndex;
}